"""Offline-only C09 CLI. Deliberately no provider/key/response arguments."""

import argparse

from . import export, load, prepare


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("check", "prepare"))
    parser.add_argument("--split", choices=("all", "development", "evaluation"), default="all")
    parser.add_argument("--output")
    args = parser.parse_args()
    if args.command == "check":
        load()
        print("heldout-v1: fixture hashes and contracts PASS; live approval pending")
    else:
        if not args.output:
            parser.error("prepare requires a fresh --output directory")
        report = prepare(split=args.split)
        export(report, args.output)
        print(f"TEST_ONLY: {report['planned_slots']} slots; zero provider calls")


if __name__ == "__main__":
    main()
